package com.fsap.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FsapApplicationTests {

	@Test
	void contextLoads() {
	}

}
